package assignment1;
import java.util.Scanner;
public class Calculator {
    public static void main(String args[]) {
        Scanner s1 = new Scanner(System.in);
        int choice;
        int num1, num2, r;

        do {
            System.out.println("\nEnter two numbers:");
            num1 = s1.nextInt();
            num2 = s1.nextInt();

            System.out.println("1. Add");
            System.out.println("2. Subtract");
            System.out.println("3. Multiply");
            System.out.println("4. Divide");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");
            choice = s1.nextInt();

            switch (choice) {
                case 1:
                    r = num1 + num2;
                    System.out.println("Sum = " + r);
                    break;
                case 2:
                    r = num1 - num2;
                    System.out.println("Subtraction = " + r);
                    break;
                case 3:
                    r = num1 * num2;
                    System.out.println("Multiplication = " + r);
                    break;
                case 4:
                    if (num2 != 0) {
                        r = num1 / num2;
                        System.out.println("Division = " + r);
                    } else {
                        System.out.println("Cannot divide by zero.");
                    }
                    break;
                case 0:
                    System.out.println("Calculator exited.");
                    break;
                default:
                    System.out.println("Invalid choice.");
            }

        } while (choice != 0);

        s1.close();
    }
}