package assignment1;

import java.util.Scanner;

public class GradingSystem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter total marks: ");
        int total = sc.nextInt();

        System.out.print("Enter maths marks: ");
        int maths = sc.nextInt();

        if (total < 20) {
            System.out.println("Fail");
        } else if (total >= 20 && total < 40 && maths < 20) {
            System.out.println("Grade D");
        } else if (total >= 40 && total < 60 && maths > 30) {
            System.out.println("Grade C");
        } else if (total >= 60 && total < 80 && maths > 60) {
            System.out.println("Grade B");
        } else if (total >= 80 && total <= 100 && maths > 80) {
            System.out.println("Grade A");
        } else {
            System.out.println("No grade");
        }

        sc.close();
    }
}
