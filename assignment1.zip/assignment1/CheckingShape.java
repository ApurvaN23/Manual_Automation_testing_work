
//Take values of length and breadth and check if it is a rectangle or a square

package assignment1;
import java.util.Scanner;
public class CheckingShape {
	
	public static void main(String args[])
	
	{
		Scanner s1=new Scanner(System.in);
		int len=s1.nextInt();
		int br=s1.nextInt();
		
		if(len<=0 || br<=0)
		{
			System.out.print("length and breath should not be zero or less than zero");
			
		}else if(len!=br)
		{
			System.out.println("this is rectangle");
			
		}
		else
		{
			System.out.println("this is square");
			
		}
	}
	
	

}
