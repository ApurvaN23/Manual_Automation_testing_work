package assignment1;

public class MultiplicationTable {
	 public static void main(String[] args) {
	        int num = 29;
	        int i = 1;

	        System.out.println("Multiplication Table of 29:");

	        while (i <= 10) {
	            System.out.println(num + " x " + i + " = " + (num * i));
	            i++;
	            
//	            using forloop
//	            for (int i = 1; i <= 10; i++) {
//	                System.out.println(num + " x " + i + " = " + (num * i));
//	            }
	        }
	    }

}
