package assignment1;

import java.util.Scanner;

public class CheckNumberPositiveNegative {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num = 0;

        do {
            System.out.print("Enter a number: ");
            String input = sc.nextLine();

            try {
                num = Integer.parseInt(input);

                if (num > 0) {
                    System.out.println("The number is positive.");
                } else if (num < 0) {
                    System.out.println("The number is negative.");
                } else {
                    System.out.println("The number is zero.");
                }

            } catch (NumberFormatException e) {
                System.out.println("Invalid input! Please enter a valid integer.");
                num = 1;
            }

        } while (num > 0);

        System.out.println("Program ended.");
        sc.close();
    }
}
