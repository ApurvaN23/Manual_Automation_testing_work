
//2> Find largest between 4 numbers 
package assignment1;
import java.util.Scanner;
public class LargestOfFour {
	
//	public static void main(String arg[])
//	{
//		Scanner s1=new Scanner(System.in);
//		int a=s1.nextInt();
//		int b=s1.nextInt();
//		int c=s1.nextInt();
//		int d=s1.nextInt();
//		
//		int max= Math.max(Math.max(a, b), Math.max(c, d));
//		
//		System.out.println("Maximun number is "+max);
//	}
//
//}

//2nd approach

//	public static void main(String arg[])
//	{
//		
//		Scanner sc = new Scanner(System.in);
//
//        int a = sc.nextInt();
//        int b = sc.nextInt();
//        int c = sc.nextInt();
//        int d = sc.nextInt();
//        
//        if(a>b && a>c && a>d)
//        {
//        	System.out.println(a);
//        	
//        }
//        else if(b>a && b>c && b>d)
//        {
//        	System.out.println(b);
//        }
//        else if(c>a && c>b && c>d)
//        {
//        	System.out.println(c);
//        }
//        else
//        {
//        	System.out.println(d);
//        }
//		
//		
//	}
	
	//3rd approach
	
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int[] nums = new int[4];
        for (int i = 0; i < 4; i++) {
            nums[i] = sc.nextInt();
        }

        int max = nums[0];
        for (int i = 1; i < nums.length; i++) {
            if (nums[i] > max) {
                max = nums[i];
            }
        }

        System.out.println("The largest number is: " + max);

        sc.close();
    }
}	
	

