package assignment1;

public class EvenSum {
	public static void main(String[] args) {
        int sum = 0; // Start with 0

        for (int i = 2; i <= 50; i=i+2) { // From 2 to 50, step by 2
            sum += i; // Add i to sum
        }

        System.out.println("Sum of even numbers from 1 to 50 is: " + sum);
    }

}
