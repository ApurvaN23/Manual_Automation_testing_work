package assignment1;

public class First10OddNumbers {
    public static void main(String[] args) {
        int count = 0, num = 1;

        System.out.println("First 10 odd numbers:");
        while (count < 10) { 
            System.out.println(num);
            num += 2; //num=num+2;
            count++;
        }
    }
}
//for (int i = 1; i <= 10; i++) {
//System.out.println(2 * i - 1);
//}

//for (int i = 1, count = 0; count < 10; i++) {
//    if (i % 2 != 0) {
//        System.out.println(i);
//        count++;
//    }
//}

